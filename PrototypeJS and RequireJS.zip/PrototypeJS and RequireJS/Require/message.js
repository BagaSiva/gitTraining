﻿define(function () {
    return 'Hello world… I am message module';
});


// next level
// as we can not define more than one default module use module name to define new module
define('another-module', function () {
    return ' - I am Another module';
});
