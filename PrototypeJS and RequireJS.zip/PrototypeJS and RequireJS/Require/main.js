﻿

// Multiple modules 
require(['jquery', 'message', 'another-module'],
    function ( $,message, anotherModule) {
        // message is setting dependency for message.js file
        
    $('#output').html(message+ " - " +anotherModule);
});