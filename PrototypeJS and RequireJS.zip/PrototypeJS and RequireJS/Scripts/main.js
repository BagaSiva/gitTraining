﻿window.alert("hello require");

/*
require(['jquery'],function ($){
    // define array of  modules to be loaded by require module 
    // ensure that jquery.js is referred in your project

    // write jquery code here
    $('#output').html('hello … this is my first jquery module');
});

*/

/*
// passing dependency to require module as parameter
require(['jquery','message'], function ($,message) {
    // message is setting dependency for message.js file

  
    $('#output').html(message);
});
*/

// Multiple modules 
//require(['jquery', 'message', 'another-module'], function ($, message, anotherModule) {
//    // message is setting dependency for message.js file


//    $('#output').html(message+ " - " +anotherModule);
//});