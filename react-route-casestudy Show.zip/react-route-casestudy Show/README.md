''' bash 
To build

>npm build   or  
> npm webpack

To watch   
>npm watch

To run
>npm start

