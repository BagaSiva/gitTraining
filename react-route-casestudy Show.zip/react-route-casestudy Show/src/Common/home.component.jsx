import React, { Component } from 'react';

class Home extends Component {
    render(){
        return (
        <h1 className='bg-success'>Welcome to Murthy Car Shopping......
        </h1>
        );
    }
}

export default Home